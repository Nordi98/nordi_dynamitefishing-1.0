local QBCore = exports['qb-core']:GetCoreObject()
local cooldowns = {}

-- Item-Check Callback
QBCore.Functions.CreateCallback('dynamitefishing:checkItem', function(source, cb, item)
    local player = QBCore.Functions.GetPlayer(source)
    cb(player and player.Functions.GetItemByName(item) ~= nil)
end)

-- Item-Entfernung
RegisterNetEvent('dynamitefishing:removeItem', function()
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    if player then
        player.Functions.RemoveItem(Config.RequiredItem, 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[Config.RequiredItem], 'remove')
    end
end)

-- Belohnungssystem
RegisterNetEvent('dynamitefishing:reward', function()
    local src = source
    local player = QBCore.Functions.GetPlayer(src)
    
    -- Cooldown-Check
    if cooldowns[src] and os.time() - cooldowns[src] < Config.Cooldown then
        return QBCore.Functions.Notify(src, string.format('Warte %s Sekunden!', Config.Cooldown), 'error')
    end
    
    -- Belohnungen geben
    local rewardGiven = false
    for _, reward in ipairs(Config.FishRewards) do
        if math.random(1, 100) <= reward.chance then
            local amount = type(reward.amount) == 'table' and math.random(reward.amount[1], reward.amount[2]) or reward.amount
            player.Functions.AddItem(reward.name, amount)
            TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[reward.name], 'add')
            rewardGiven = true
            break
        end
    end
    
    -- Fallback-Belohnung, falls keine andere gegeben wurde
    if not rewardGiven then
        player.Functions.AddItem('fish_common', 1)
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items['fish_common'], 'add')
    end

    cooldowns[src] = os.time()
end)

-- Item-Nutzung registrieren
QBCore.Functions.CreateUseableItem(Config.RequiredItem, function(source)
    TriggerClientEvent('dynamitefishing:useItem', source)
end)
