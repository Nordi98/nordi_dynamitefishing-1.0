
Config = {}

-- CORE SETTINGS
Config.RequiredItem = 'dynamite' -- Item für Dynamite Fishing
Config.Cooldown = 120 -- Cooldown in Sekunden

-- GAMEPLAY
Config.SkillCheck = {
    difficulty = {'easy', 'easy', 'easy'}, -- OxLib Skill-Check
    keys = {'e', 'e', 'e', 'e'}
}

Config.Explosion = {
    type = 29, -- EXPLOSION_PIPEBOMB
    volume = 1.0,
    cameraShake = true
}


-- REWARDS
Config.FishRewards = {
    { name = 'salmon', chance = 75, amount = {1, 3} },
    { name = 'tuna', chance = 75, amount = {1, 3} },
    { name = 'trout', chance = 20, amount = {1, 2} },
    { name = 'pufferfish', chance = 5, amount = 1 }
}
