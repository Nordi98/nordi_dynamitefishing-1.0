Dynamite Fishing Script
🇩🇪 Deutsche README
Übersicht
Dieses Script ermöglicht Dynamitfischen in FiveM mit QB-Core und ps-dispatch Integration. Spieler können Dynamite ins Wasser werfen, um Fische zu fangen, mit Risiko einer Polizeimeldung.

Features:
-Realistisches Dynamitfischen: Wirf eine Rohrbombe ins Wasser und sammle betäubte Fische
-Skill-Check System: Nutzt ox_lib für Timing-basierte Herausforderungen
-Automatische Polizeimeldungen: Explosionen werden über ps-dispatch an die Polizei gemeldet
-Verschiedene Fischarten: Unterschiedliche Seltenheiten und Belohnungen
-Cooldown-System: Verhindert Spam und Missbrauch

Installation:
1.Kopiere den Ordner dynamite_fishing in deinen resources Ordner
2.Füge ensure dynamite_fishing zu deiner server.cfg hinzu
3.Stelle sicher, dass die Items in qb-core/shared/items.lua existieren:

['dynamite'] = { name = 'dynamite', label = 'Dynamite', weight = 600, ... }
['fish_common'] = { name = 'fish_common', label = 'Gewöhnlicher Fisch', weight = 200, ... }
['fish_uncommon'] = { name = 'fish_uncommon', label = 'Ungewöhnlicher Fisch', weight = 300, ... }
['fish_rare'] = { name = 'fish_rare', label = 'Seltener Fisch', weight = 500, ... }

4.Starte deinen Server neu oder lade die Ressource.

Verwendung:
-Befehl: /dynamitefish - Startet das Dynamitfischen (wenn du in Richtung Wasser schaust)
-Item-Nutzung: Verwende die Rohrbombe aus deinem Inventar
-Skill-Check: Bestehe den Timing-Test, um die Explosion auszulösen
-Sammeln: Nach der Explosion werden automatisch Fische gesammelt

Konfiguration
In der config.lua kannst du folgende Einstellungen anpassen:

-Benötigtes Item und Cooldown-Zeit
-Skill-Check Schwierigkeit
-Explosionsparameter
-Fischbelohnungen und Seltenheiten

Abhängigkeiten:
-QB-Core Framework
-ox_lib (für Skill-Checks)
-ps-dispatch (für Polizeimeldungen)

Credits
Entwickelt von Nordi Designes

Discord für Support: https://discord.gg/QpZsNS6CGz