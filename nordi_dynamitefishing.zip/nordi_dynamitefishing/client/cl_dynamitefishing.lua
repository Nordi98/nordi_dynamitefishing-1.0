local QBCore = exports['qb-core']:GetCoreObject()
local isActive = false

-- Funktion zum Prüfen, ob der Spieler in Richtung Wasser schaut
local function IsPlayerFacingWater()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local heading = GetEntityHeading(ped)
    
    -- Berechne Punkt in Blickrichtung (5 Einheiten vor dem Spieler)
    local radians = math.rad(heading)
    local forwardX = coords.x + 5.0 * math.sin(-radians)
    local forwardY = coords.y + 5.0 * math.cos(-radians)
    
    -- Prüfe Wasserhöhe an dieser Position
    local waterZ = 0.0
    local success, waterHeight = GetWaterHeight(forwardX, forwardY, coords.z, waterZ)
    
    -- Wenn GetWaterHeight erfolgreich ist und Wasser in Sichtlinie ist
    if success then
        -- Prüfe, ob Wasser in angemessener Höhe ist (nicht zu weit unten oder oben)
        local heightDiff = math.abs(waterHeight - coords.z)
        return heightDiff < 5.0 -- Wasser ist maximal 5 Einheiten über/unter dem Spieler
    end
    
    -- Alternative Methode: Teste mehrere Punkte vor dem Spieler
    for distance = 1.0, 10.0, 1.0 do
        local checkX = coords.x + distance * math.sin(-radians)
        local checkY = coords.y + distance * math.cos(-radians)
        local checkZ = coords.z - 1.0 -- Etwas unter Augenhöhe
        
        -- Prüfe, ob dieser Punkt im Wasser ist
        if IsPointInWater(checkX, checkY, checkZ) then
            return true
        end
    end
    
    return false
end

-- Hauptfunktion
local function StartDynamiteFishing()
    local ped = PlayerPedId()
    
    -- Prüfungen
    if isActive then 
        return QBCore.Functions.Notify('Du bist bereits beim Fischen!', 'error') 
    end
    
    -- Prüfe, ob Spieler in Richtung Wasser schaut
    if not IsPlayerFacingWater() then
        return QBCore.Functions.Notify('Du musst in Richtung Wasser schauen!', 'error')
    end
    
    isActive = true
    
    -- Item-Check
    QBCore.Functions.TriggerCallback('dynamitefishing:checkItem', function(hasItem)
        if not hasItem then
            isActive = false
            return QBCore.Functions.Notify('Du brauchst Dynamit!', 'error')
        end

        -- Wurf-Animation
        local throwDict = "melee@unarmed@streamed_variations"
        local throwAnim = "plyr_takedown_front_slap"
        
        RequestAnimDict(throwDict)
        while not HasAnimDictLoaded(throwDict) do
            Wait(10)
        end
        
        TaskPlayAnim(ped, throwDict, throwAnim, 8.0, -8.0, -1, 0, 0, false, false, false)
        Wait(1500)
        ClearPedTasks(ped)

        -- SKILL CHECK DIREKT NACH DEM WURF
        if not lib.skillCheck(Config.SkillCheck.difficulty, Config.SkillCheck.keys) then
            TriggerServerEvent('dynamitefishing:removeItem')
            isActive = false
            return QBCore.Functions.Notify('Fehlgeschlagen! Das Dynamit ist ins Wasser gefallen.', 'error')
        end

        -- Berechne Position für Explosion (etwas vor dem Spieler im Wasser)
        local coords = GetEntityCoords(ped)
        local heading = GetEntityHeading(ped)
        local radians = math.rad(heading)
        local explosionX = coords.x + 9.0 * math.sin(-radians)
        local explosionY = coords.y + 9.0 * math.cos(-radians)
        local explosionZ = coords.z - 3.0 -- Etwas unter der Wasseroberfläche
        
        -- EXPLOSION DIREKT NACH ERFOLGREICHEM SKILL CHECK
        AddExplosion(explosionX, explosionY, explosionZ, Config.Explosion.type, Config.Explosion.volume, true, false, Config.Explosion.cameraShake)
        
        
        -- Item entfernen (nach erfolgreicher Explosion)
        TriggerServerEvent('dynamitefishing:removeItem')
        
        -- Sammel-Animation nach der Explosion
        local collectDict = "anim@amb@clubhouse@tutorial@bkr_tut_ig3@"
        local collectAnim = "machinic_loop_mechandplayer"
        
        RequestAnimDict(collectDict)
        while not HasAnimDictLoaded(collectDict) do
            Wait(10)
        end
        
        TaskPlayAnim(ped, collectDict, collectAnim, 8.0, -8.0, -1, 1, 0, false, false, false)
        
        -- Progressbar für das Sammeln der Fische
        QBCore.Functions.Progressbar('dynamite_fishing', 'Fische sammeln...', 5000, false, true, {
            disableMovement = true,
            disableCarMovement = true
        }, {}, {}, {}, function()
            -- Belohnungen nach dem Sammeln
            TriggerServerEvent('dynamitefishing:reward')
            ClearPedTasks(ped)
            isActive = false
        end)
    end, Config.RequiredItem)
end

-- Hilfsfunktion: Prüft, ob ein Punkt im Wasser ist
function IsPointInWater(x, y, z)
    return TestProbeAgainstWater(x, y, z, x, y, z - 10.0)
end

-- Befehl registrieren
RegisterCommand('dynamitefish', StartDynamiteFishing)

-- Item-Nutzung registrieren
RegisterNetEvent('dynamitefishing:useItem', function()
    StartDynamiteFishing()
end)

-- Item-Nutzung mit QB-Core verbinden
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    TriggerEvent('inventory:client:ItemBox', QBCore.Shared.Items[Config.RequiredItem], 'add')
end)
