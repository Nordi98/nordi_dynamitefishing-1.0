fx_version 'cerulean'
game 'gta5'
lua54 'yes'  -- Aktiviert Lua 5.4 Unterstützung

author 'YourName'
description 'QB-Core Dynamite Fishing Script mit PS-Dispatch Integration'
version '1.0.0'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'config.lua',
}

client_scripts {
    '@ox_lib/init.lua',
    'client/cl_dynamitefishing.lua'
}

server_scripts {
    'server/sv_dynamitefishing.lua'
}

dependencies {
    'qb-core',
    'ox_lib',
    'ps-dispatch'
}
